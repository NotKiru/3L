package com.example.i_am_speed;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import java.util.*;

public class MainActivity extends AppCompatActivity{

    String dist_unit1 = "m", dist_unit2 = "m";
    String spec_unit1, spec_unit2;
    String time_unit1 = "s", time_unit2 = "s";

    boolean is_special_1 = false, is_special_2 = false;

    Spinner dist_select_1, spec_select_1, time_select_1, dist_select_2, spec_select_2, time_select_2;
    Button cisk;

    TextView res;

    EditText unit_input;

    CheckBox spec_check_1, spec_check_2;
    private static final String[] distance_units = {"m", "km", "dm", "cm", "mm", "in", "ft", "yd", "mi"};
    private static final String[] special_units = {"c (v światła)", "kt", "mach", "c (v dźwięku)"};
    private static final String[] time_units = {"s", "h", "min"};
    HashMap<String, Float> distance_to_meters = new HashMap<String, Float>();
    HashMap<String, Float> special_units_to_ms = new HashMap<String, Float>();
    HashMap<String, Float> time_to_s = new HashMap<String, Float>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cisk = (Button)findViewById(R.id.button);
        unit_input = (EditText)findViewById(R.id.unit_input);

        dist_select_1 = (Spinner)findViewById(R.id.distance_unit_select_1);
        dist_select_2 = (Spinner)findViewById(R.id.distance_unit_select_2);
        spec_select_1 = (Spinner)findViewById(R.id.special_unit_select_1);
        spec_select_2 = (Spinner)findViewById(R.id.special_unit_select_2);
        time_select_1 = (Spinner)findViewById(R.id.time_unit_select_1);
        time_select_2 = (Spinner)findViewById(R.id.time_unit_select_2);

        res = (TextView)findViewById(R.id.resault);

        spec_check_1 = (CheckBox)findViewById(R.id.special_check_1);
        spec_check_2 = (CheckBox)findViewById(R.id.special_check_2);

        ArrayAdapter<String> dist_adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_item,distance_units);
        ArrayAdapter<String> spec_adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_item,special_units);
        ArrayAdapter<String> time_adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_item,time_units);

        dist_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spec_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        time_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        dist_select_1.setAdapter(dist_adapter);
        dist_select_1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                dist_unit1 = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        dist_select_2.setAdapter(dist_adapter);
        dist_select_2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                dist_unit2 = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spec_select_1.setAdapter(spec_adapter);
        spec_select_1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spec_unit1 = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spec_select_2.setAdapter(spec_adapter);
        spec_select_2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spec_unit2 = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        time_select_1.setAdapter(time_adapter);
        time_select_1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                time_unit1 = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        time_select_2.setAdapter(time_adapter);
        time_select_2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                time_unit2 = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spec_check_1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView,boolean isChecked) {
                is_special_1 = isChecked;

                if(isChecked) {
                    spec_select_1.setVisibility(View.VISIBLE);
                    dist_select_1.setVisibility(View.INVISIBLE);
                    time_select_1.setVisibility(View.INVISIBLE);
                } else {
                    spec_select_1.setVisibility(View.INVISIBLE);
                    dist_select_1.setVisibility(View.VISIBLE);
                    time_select_1.setVisibility(View.VISIBLE);
                }

            }
        });

        spec_check_2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView,boolean isChecked) {
                is_special_2 = isChecked;

                if(isChecked) {
                    spec_select_2.setVisibility(View.VISIBLE);
                    dist_select_2.setVisibility(View.INVISIBLE);
                    time_select_2.setVisibility(View.INVISIBLE);
                } else {
                    spec_select_2.setVisibility(View.INVISIBLE);
                    dist_select_2.setVisibility(View.VISIBLE);
                    time_select_2.setVisibility(View.VISIBLE);
                }
            }
        });



        distance_to_meters.put("km", 1000f);
        distance_to_meters.put("m", 1f);
        distance_to_meters.put("dm", 0.1f);
        distance_to_meters.put("cm", 0.01f);
        distance_to_meters.put("mm", 0.001f);
        distance_to_meters.put("in", 0.0254f);
        distance_to_meters.put("ft", 0.3048f);
        distance_to_meters.put("yd", 0.9144f);
        distance_to_meters.put("mi", 1609.344f);

        special_units_to_ms.put("c (v światła)" , 299792458f);
        special_units_to_ms.put("kt" , 0.5144f);
        special_units_to_ms.put("mach" , 295.0464f);
        special_units_to_ms.put("c (v dźwięku)", 343f);

        time_to_s.put("h" , 3600f);
        time_to_s.put("min" , 60f);
        time_to_s.put("s" , 1f);

        cisk.setOnClickListener(v -> {
            String result_s;
            float result;
            float number;

            try {
                number = Float.parseFloat(unit_input.getText().toString());

                result = number;
                if(is_special_1) {
                    result *= special_units_to_ms.get(spec_unit1);
                } else {
                    result *= (float)(distance_to_meters.get(dist_unit1) / time_to_s.get(time_unit1));
                }


                if(is_special_2) {
                    result /= special_units_to_ms.get(spec_unit2);
                } else {
                    result /= (float)(distance_to_meters.get(dist_unit2) / time_to_s.get(time_unit2));
                }

                if(is_special_1 && is_special_2) {
                    result_s = number + spec_unit1 + " = " + result + spec_unit2;
                } else if(is_special_1) {
                    if(spec_unit1 == "c (v światła)") {
                        result_s = number + spec_unit1 + " = " + (int)result + dist_unit2   + "/" + time_unit2;
                    } else {
                        result_s = number + spec_unit1 + " = " + result + dist_unit2 + "/" + time_unit2;
                    }
                } else if(is_special_2) {
                    result_s = number + dist_unit1 + "/" + time_unit1 + " = " + result + spec_unit2;
                } else {
                    result_s = number + dist_unit1 + "/" + time_unit1 + " = " + result + dist_unit2   + "/" + time_unit2;
                }

                res.setText(result_s);
            } catch(NumberFormatException e) {
                res.setText("Coś poszło nie tak :(");
            }
        });

    }
}